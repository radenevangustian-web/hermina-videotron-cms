# 🏥 RS Hermina Arcamanik - Multi-Device CMS
### 1 Videotron 4x3m Single Pole 5.0m (turun 1.0m) + 5 TV Kiosk + Kanopi 1.5m

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/YOUR_USERNAME/hermina-videotron-cms)

Device: Videotron Utama 4x3m, tinggi 5.0m turun 1.0m agar logo HERMINA HOSPITAL terlihat jelas, clearance 2.5m, kanopi 1.5m hanya pathway tidak nutupi taman.
+ 5 TV Kiosk: Lobby, Poli Anak, Kandungan, Farmasi, IGD