const express = require('express');
const cors = require('cors');
const http = require('http');
const { Server } = require('socket.io');
const sqlite3 = require('sqlite3').verbose();
const { v4: uuidv4 } = require('uuid');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

const db = new sqlite3.Database('./hermina.db');

const DEVICES = [
  { id: 'videotron-01', name: 'Videotron Utama', location: 'Gerbang Utama', type: 'videotron', size: '4.0x3.0m', resolution: '4:3', height: '5.0m turun 1.0m dari 6.0m', clearance: '2.5m', status: 'online', brightness: '5500 nits', note: 'Logo HERMINA HOSPITAL 100% terlihat, Kanopi 1.5m hanya pathway' },
  { id: 'tv-kiosk-01', name: 'TV Kiosk 1 - Lobby', location: 'Lobby Utama', type: 'tv-kiosk', size: '32 inch Vertical', status: 'online', function: 'Antrian Poliklinik' },
  { id: 'tv-kiosk-02', name: 'TV Kiosk 2 - Poli Anak', location: 'Poli Anak', type: 'tv-kiosk', size: '32 inch', status: 'online', function: 'Jadwal Dokter Anak' },
  { id: 'tv-kiosk-03', name: 'TV Kiosk 3 - Kandungan', location: 'Poli Kandungan', type: 'tv-kiosk', size: '43 inch', status: 'online', function: 'Edukasi Kandungan' },
  { id: 'tv-kiosk-04', name: 'TV Kiosk 4 - Farmasi', location: 'Farmasi', type: 'tv-kiosk', size: '32 inch', status: 'online', function: 'Antrian Farmasi' },
  { id: 'tv-kiosk-05', name: 'TV Kiosk 5 - IGD', location: 'IGD', type: 'tv-kiosk', size: '55 inch', status: 'online', function: 'IGD 24 Jam' }
];

app.get('/api/devices', (req, res) => res.json(DEVICES));
app.get('/api/contents', (req, res) => {
  db.all("SELECT * FROM contents ORDER BY created_at DESC", (err, rows) => {
    if (err) res.status(500).json({error: err.message});
    else res.json(rows);
  });
});
app.post('/api/contents', (req, res) => {
  const { title, subtitle, description, target_devices, content_type, schedule } = req.body;
  const id = uuidv4();
  db.run("INSERT INTO contents (id, title, subtitle, description, target_devices, content_type, schedule, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
    [id, title, subtitle, description, JSON.stringify(target_devices), content_type, schedule, 'published'],
    function(err) {
      if (err) res.status(500).json({error: err.message});
      else {
        const newContent = { id, title, subtitle, description, target_devices, content_type, schedule };
        io.emit('content:update', newContent);
        res.json(newContent);
      }
    });
});
app.get('/api/doctors', (req, res) => {
  db.all("SELECT * FROM doctors WHERE is_active=1 ORDER BY poli", (err, rows) => {
    if (err) res.status(500).json({error: err.message});
    else res.json(rows);
  });
});
app.get('/api/queue', (req, res) => {
  res.json({ poli: { current: 'A-042', next: 'A-043', waiting: 8 }, farmasi: { current: 'F-018', waiting: 12, estimasi: '12 menit' } });
});
io.on('connection', (socket) => {
  socket.on('register-device', (deviceId) => {
    socket.join(deviceId);
    console.log('Device registered: ' + deviceId);
  });
});
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log('✅ Hermina CMS Running http://localhost:' + PORT);
});