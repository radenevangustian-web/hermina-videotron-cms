const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./hermina.db');
db.serialize(() => {
  db.run("CREATE TABLE IF NOT EXISTS contents (id TEXT PRIMARY KEY, title TEXT, subtitle TEXT, description TEXT, target_devices TEXT, content_type TEXT, schedule TEXT, status TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
  db.run("CREATE TABLE IF NOT EXISTS doctors (id TEXT PRIMARY KEY, name TEXT, poli TEXT, jam TEXT, photo TEXT, is_active INTEGER DEFAULT 1)");
  db.run("DELETE FROM doctors");
  const doctors = [['dr. Andi, Sp.PD','Penyakit Dalam','08:00-12:00'],['dr. Siti, Sp.OG','Kandungan','10:00-14:00'],['dr. Budi, Sp.A','Anak','13:00-16:00']];
  const stmt = db.prepare("INSERT INTO doctors (id, name, poli, jam) VALUES (?, ?, ?, ?)");
  doctors.forEach(d => stmt.run(require('uuid').v4(), d[0], d[1], d[2]));
  stmt.finalize();
  console.log("DB ready - 1 Videotron + 5 TV Kiosk");
});
db.close();